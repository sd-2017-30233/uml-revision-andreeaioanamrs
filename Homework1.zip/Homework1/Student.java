
public class Student {
	private String name,surname;
	private int year;
	private Quiz quiz;
	private Subject[] subjects;
	
	Student(String lName,String fName,int cYear){
		this.setName(lName);
		this.setSurname(fName);
		this.setYear(cYear);
	}
	
	private double takeExam(Subject s){	
		quiz.getInstance(s);
		return quiz.grade;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Subject[] getSubjects() {
		return subjects;
	}

	public void setSubjects(Subject[] subjects) {
		this.subjects = subjects;
	}

}
