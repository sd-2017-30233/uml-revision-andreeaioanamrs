
public class Quiz {
	private static Quiz instance = null;
	Subject subject;
	Double grade;
	protected Quiz(Subject subject){
		this.subject = subject;
		this.grade = null;
	}
	
	public static Quiz getInstance(Subject subject){
		if (instance == null){
			instance = new Quiz(subject);
		}
		return instance;}

}
